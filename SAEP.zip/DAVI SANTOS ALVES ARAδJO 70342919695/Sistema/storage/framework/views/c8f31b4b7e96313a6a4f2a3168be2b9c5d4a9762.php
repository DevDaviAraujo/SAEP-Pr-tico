
<?php $__env->startSection('conteudo'); ?>

<br>
<br>

<div class='container'>
    <div class='card'>
        <h3> Suas Atividades da turma <?php echo e($turma->nome); ?> </h3>
        <table class="table">
            <thead>
                <tr>
                <th scope="col">id</th>
                <th scope="col">Nome</th>
                <th scope="col">Descrição</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $atividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e($valor->id); ?></th>
                <td><?php echo e($valor->nome); ?></td>
                <td><?php echo e($valor->descricao); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</div>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema\resources\views/website/visualizar.blade.php ENDPATH**/ ?>