
<?php $__env->startSection('conteudo'); ?>

<br>
<br>
<center>
<div class='container'>
    <div class='card' style='width: 300px;'> <br>
        
        <h3> Cadastrar Turmas </h3>
        <form action="/cadastrar/turma" method='post'>

            Nome: <br>
            <input type="text" name='nome' required > <br> <br>

            <?php echo csrf_field(); ?>


            <input type="submit" class='btn btn-primary'><br> <br>

        </form>
    
    </div>

</div>
</center>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema\resources\views/website/turmas.blade.php ENDPATH**/ ?>