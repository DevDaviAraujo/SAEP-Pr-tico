
<?php $__env->startSection('conteudo'); ?>

<head>
    <style>
        a {
           text-decoration: none; 
        }
        a:hover {
           text-decoration: none; 
        }
    </style>
</head>

<br>
<br>

<div class='container'>
    <div class='card'>
        <h3> Suas Turmas </h3>
        <table class="table">
            <thead>
                <tr>
                <th scope="col">id</th>
                <th scope="col">Nome</th>
                <th scope="col">Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $turmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e($valor->id); ?></th>
                <td><?php echo e($valor->nome); ?></td>
                <td>
                    
                    <a class='tex-white' href="/excluir/turma/<?php echo e($valor->id); ?>"><button class='btn btn-danger'>excluir</button></a>
                    <a class='tex-white' href="/visualizar/<?php echo e($valor->id); ?>"><button class='btn btn-warning text-white'>visualizar</button></a>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</div>

    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema\resources\views/website/home.blade.php ENDPATH**/ ?>